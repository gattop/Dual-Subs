/*
 * Dual Subs - platforms/disney.js (mondo MAIN)
 *
 * Adattatore per Disney+. La risposta di riproduzione contiene l'URL della
 * playlist HLS principale (stream.sources[0].complete.url): da lì si leggono le
 * tracce di sottotitoli (hls.js). Il tempo del programma non è
 * video.currentTime (pubblicità e sigle lo spostano): si legge dal player.
 *
 * I dettagli sul funzionamento di Disney+ (posizione dell'URL della playlist,
 * orologio del player, stato delle interruzioni) sono stati ricavati studiando
 * il progetto DualSub (https://github.com/QuellaMC/DualSub); nessun codice è
 * stato copiato.
 */
(function exportDisney(root) {
  'use strict';

  const Hls = typeof module === 'object' && module.exports ? require('../hls.js') : root.DualSubsHls;

  // Elementi personalizzati del player che espongono stato e orologio
  const PLAYER_UI_SELECTOR = 'disney-web-player-ui';
  const CONTROLS_SELECTOR = 'main-app-controls-overlay';
  const ROUTE_RE = /\/(?:video|play)\/([^/?#]+)\/?$/;

  // ------------------------------------------- risposta di riproduzione

  // URL della playlist principale, nella risposta o sotto "data"
  function readMasterUrl(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    const container = value.data && typeof value.data === 'object' ? value.data : value;
    const stream = container.stream;
    const source = stream && Array.isArray(stream.sources) ? stream.sources[0] : null;
    const url = source && source.complete && source.complete.url;
    return typeof url === 'string' && url ? url : null;
  }

  // Id del titolo dal percorso /play/<id> o /video/<id>
  function routeId(pathname) {
    const m = ROUTE_RE.exec(pathname || '');
    if (!m) return null;
    try {
      return decodeURIComponent(m[1]);
    } catch (_err) {
      return m[1];
    }
  }

  // Se l'oggetto è una risposta di riproduzione: { movieId, masterUrl }, altrimenti null
  function extractPlayback(value, pathname) {
    const masterUrl = readMasterUrl(value);
    if (!masterUrl) return null;
    return { movieId: routeId(pathname) || 'disney:' + masterUrl.split('?')[0], masterUrl };
  }

  // Versione per page.js: le tracce si leggono scaricando la playlist principale
  function extract(value) {
    const found = extractPlayback(value, root.location.pathname);
    if (!found) return null;
    return {
      movieId: found.movieId,
      resultKeys: [],
      loadTracks: async (fetchText) => {
        const master = await fetchText(found.masterUrl);
        return Hls.parseMasterSubtitles(master.text, master.url || found.masterUrl);
      }
    };
  }

  // ------------------------------------------- pagina

  // Disney+ monta più video (anche anteprime): si sceglie quello che sta
  // davvero riproducendo, il più grande a parità di condizioni
  function videoScore(video) {
    const area = video.clientWidth * video.clientHeight;
    if (!video.isConnected || area === 0) return -1;
    let score = Math.min(area / 10000, 100);
    if (video.readyState >= 2) score += 40;
    if (!video.paused && !video.ended) score += 30;
    if (video.currentTime > 0) score += 10;
    return score;
  }

  function findVideo() {
    let best = null;
    let bestScore = -1;
    for (const video of root.document.querySelectorAll('video')) {
      const score = videoScore(video);
      if (score > bestScore) {
        best = video;
        bestScore = score;
      }
    }
    return best;
  }

  function currentTitle() {
    return findVideo() ? routeId(root.location.pathname) : null;
  }

  // Proprietà che il player appende ai suoi elementi personalizzati
  function hostProperty(selector, property) {
    const host = root.document.querySelector(selector);
    return host ? host[property] : undefined;
  }

  function isInterstitialPlaying() {
    const store = hostProperty(CONTROLS_SELECTOR, 'store');
    return Boolean(store && store.interstitials && store.interstitials.isInterstitialPlaying);
  }

  // Tempo del programma in secondi; null durante pubblicità e interruzioni
  // (niente sottotitoli). Se il player non lo espone si usa il tempo del video.
  function getTime(video) {
    try {
      if (isInterstitialPlaying()) return null;
      const api = hostProperty(PLAYER_UI_SELECTOR, 'mediaPlayerApi');
      const info = api && api.timeline && api.timeline.info;
      const ms = info && info.playheadPositionMs;
      if (typeof ms === 'number' && Number.isFinite(ms) && ms >= 0) return ms / 1000;
    } catch (_err) {
      // struttura del player cambiata: si ripiega sul tempo del video
    }
    return video.currentTime;
  }

  const adapter = {
    name: 'disney',
    matches: (hostname) => /(^|\.)disneyplus\.com$/.test(hostname),
    beforeStringify: null,
    extract,
    currentTitle,
    findVideo,
    getTime,
    containerSelectors: [] // il contenitore è il genitore del video
  };

  const api = { readMasterUrl, routeId, extractPlayback, adapter };

  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    (root.DualSubsPlatforms = root.DualSubsPlatforms || []).push(adapter);
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
