/*
 * Dual Subs - page.js (mondo MAIN)
 *
 * Coordina il lavoro nella pagina Netflix: hook su JSON (dati in tracks.js),
 * navigazione tra titoli, download dei WebVTT (parser in vtt-parser.js),
 * overlay (overlay.js). Non ha accesso a chrome.*: comunica con content.js
 * tramite window.postMessage.
 *
 * La tecnica degli hook su JSON.stringify / JSON.parse è adattata da Subadub
 * (https://github.com/rsimmons/subadub, dist/page_script.js).
 * Copyright (c) 2018 Russel Simmons - licenza MIT, testo completo in
 * THIRD_PARTY_NOTICES.md.
 */
(function initDualSubsPage() {
  'use strict';

  // Deve coincidere con "version" in manifest.json: serve a capire dai log
  // se la pagina sta usando il codice aggiornato
  const BUILD_VERSION = '1.0.0';
  const MSG_SOURCE = 'dual-subs';
  const LOG_PREFIX = '[DualSubs]';
  const NO_RESPONSE_WARN_MS = 20000;
  const TICK_MS = 1000;
  // Attesa prima di usare un manifest con id diverso da quello nell'URL
  const FALLBACK_DELAY_MS = 8000;

  const Tracks = window.DualSubsTracks;
  const Vtt = window.DualSubsVtt;
  const Overlay = window.DualSubsOverlay;
  const DEBUG = readDebugFlag();

  let settings = null; // ricevute da content.js
  const trackCache = new Map(); // movieId -> tracce normalizzate
  const cueCache = new Map(); // URL del WebVTT -> battute
  let lastCapturedMovieId = null;
  let lastInjectionAt = 0;
  let lastCaptureAt = 0;

  let currentWatchId = null; // id nell'URL /watch/<id>, null fuori dal player
  let watchSince = 0;
  let warnedFallbackFor = null;
  let activeKey = null; // "movieId|lingua" delle battute richieste
  let loadToken = 0; // scarta i download superati da un cambio
  let loadStatus = null; // esito dell'ultimo caricamento
  let lastStatusJson = null;

  // ---------------------------------------------------------------- utilità

  // I log dettagliati si attivano dalla console di Netflix con
  // localStorage.dualSubsDebug = '1' (e si disattivano con delete)
  function readDebugFlag() {
    try {
      return window.localStorage.getItem('dualSubsDebug') === '1';
    } catch (_err) {
      return false;
    }
  }

  function log(...args) {
    if (DEBUG) console.log(LOG_PREFIX, ...args);
  }

  function warn(...args) {
    console.warn(LOG_PREFIX, ...args);
  }

  function postToContent(type, payload) {
    window.postMessage({ source: MSG_SOURCE, from: 'page', type, payload }, '*');
  }

  // Comunica lo stato a content.js (e quindi al popup), solo se è cambiato
  function postStatus(movieId, state, cueCount) {
    const payload = { movieId, state, cueCount: cueCount || 0 };
    const json = JSON.stringify(payload);
    if (json === lastStatusJson) return;
    lastStatusJson = json;
    postToContent('status', payload);
  }

  // ------------------------------------------------------ hook su JSON

  function onStringify(value) {
    const path = Tracks.injectWebvttProfile(value);
    if (!path) return;
    lastInjectionAt = Date.now();
    log('profilo', Tracks.WEBVTT_PROFILE, 'aggiunto alla lista in', path);
    setTimeout(checkResponseArrived, NO_RESPONSE_WARN_MS);
  }

  // Avvisa se la richiesta è stata modificata ma nessun manifest è mai arrivato
  function checkResponseArrived() {
    if (trackCache.size === 0 && lastCaptureAt < lastInjectionAt) {
      warn('richiesta del manifest modificata ma nessuna risposta con movieId intercettata');
    }
  }

  function onParsed(value, via) {
    const manifest = Tracks.extractManifest(value);
    if (!manifest) return;
    lastCaptureAt = Date.now();
    if (!manifest.tracks) {
      warn('manifest con movieId', manifest.movieId, 'ma senza tracce di testo riconosciute. ' +
        'Chiavi di result:', manifest.resultKeys.join(', '));
      return;
    }
    trackCache.set(manifest.movieId, manifest.tracks);
    lastCapturedMovieId = manifest.movieId;
    logTrackTable(manifest, via);
    postToContent('tracks', { movieId: manifest.movieId, tracks: Tracks.publicTracks(manifest.tracks) });
    update();
  }

  function logTrackTable(manifest, via) {
    if (!DEBUG) return;
    log('movieId', manifest.movieId, '-', manifest.tracks.length, 'tracce di testo (via ' + via + ')');
    console.table(manifest.tracks.map((t) => ({
      id: t.id,
      lingua: t.language,
      descrizione: t.label,
      tipo: t.isClosedCaptions ? 'CC' : 'sottotitoli',
      webvtt: t.vttUrl ? 'sì' : 'NO',
      formati: t.formats.join(', ')
    })));
  }

  // Ogni hook è in try/catch e restituisce sempre il risultato originale
  function installJsonHooks() {
    const originalStringify = JSON.stringify;
    JSON.stringify = function dualSubsStringify(value) {
      try {
        onStringify(value);
      } catch (err) {
        warn('errore nell\'hook di JSON.stringify:', err);
      }
      return originalStringify.apply(this, arguments);
    };

    const originalParse = JSON.parse;
    JSON.parse = function dualSubsParse() {
      const value = originalParse.apply(this, arguments);
      try {
        onParsed(value, 'JSON.parse');
      } catch (err) {
        warn('errore nell\'hook di JSON.parse:', err);
      }
      return value;
    };
  }

  // Se Netflix legge la risposta con Response.json() invece di JSON.parse,
  // l'hook precedente non la vede. Qui si osserva soltanto.
  function installResponseJsonHook() {
    const originalJson = Response.prototype.json;
    Response.prototype.json = function dualSubsResponseJson() {
      const promise = originalJson.apply(this, arguments);
      promise.then((value) => {
        try {
          onParsed(value, 'Response.json');
        } catch (err) {
          warn('errore nell\'hook di Response.json:', err);
        }
      }, () => {});
      return promise;
    };
  }

  // ----------------------------------------------- caricamento battute

  // Scarica (o prende dalla cache) il WebVTT scelto per il titolo
  async function loadSubtitlesFor(movieId) {
    activeKey = movieId + '|' + settings.language;
    const token = ++loadToken;
    Overlay.setCues([]);
    const tracks = trackCache.get(movieId) || [];
    const track = Tracks.pickTrack(tracks, settings.language);
    if (!track) {
      log('lingua "' + settings.language + '" non disponibile per movieId', movieId);
      return setLoadStatus(movieId, 'unavailable');
    }
    if (cueCache.has(track.vttUrl)) return applyCues(movieId, cueCache.get(track.vttUrl));
    log('scarico', track.label, '(' + track.language + ') per movieId', movieId);
    setLoadStatus(movieId, 'loading');
    try {
      const response = await fetch(track.vttUrl);
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const text = await response.text();
      if (token !== loadToken) return; // nel frattempo sono cambiati titolo o lingua
      const cues = Vtt.parseVtt(text);
      if (!cues.length) warn('WebVTT scaricato ma 0 battute riconosciute. Inizio:', text.slice(0, 200));
      cueCache.set(track.vttUrl, cues);
      applyCues(movieId, cues);
    } catch (err) {
      if (token !== loadToken) return;
      warn('download del WebVTT fallito:', err);
      setLoadStatus(movieId, 'error');
    }
  }

  function applyCues(movieId, cues) {
    log(cues.length, 'battute pronte (' + settings.language + ')');
    Overlay.setCues(cues);
    setLoadStatus(movieId, 'loaded', cues.length);
  }

  function setLoadStatus(movieId, state, cueCount) {
    loadStatus = { movieId, state, cueCount };
    postStatus(movieId, state, cueCount);
  }

  // Dimentica le battute correnti (cambio titolo o uscita)
  function resetSubtitles() {
    loadToken++;
    activeKey = null;
    loadStatus = null;
    Overlay.setCues([]);
  }

  // ------------------------------------------------------ navigazione

  function readWatchId() {
    const m = /\/watch\/(\d+)/.exec(location.pathname);
    return m ? m[1] : null;
  }

  // Netflix è una single page app: l'URL cambia senza ricaricare la pagina
  function onLocationMaybeChanged() {
    const watchId = readWatchId();
    if (watchId === currentWatchId) return;
    const previous = currentWatchId;
    currentWatchId = watchId;
    watchSince = Date.now();
    if (watchId) {
      enterTitle(watchId, previous);
    } else {
      leavePlayer();
    }
  }

  // Nuovo titolo o episodio successivo
  function enterTitle(watchId, previous) {
    log(previous ? 'cambio titolo: ' + previous + ' -> ' + watchId : 'titolo in riproduzione: ' + watchId);
    resetSubtitles();
    Overlay.start();
    postStatus(null, 'waiting');
    update();
  }

  // Ritorno al catalogo
  function leavePlayer() {
    log('uscita dal player');
    resetSubtitles();
    Overlay.stop();
    postStatus(null, 'idle');
  }

  // Manifest del titolo corrente. Se l'id dell'URL non corrisponde a nessun
  // manifest, dopo un'attesa si ripiega sull'ultimo intercettato.
  function resolveMovieId() {
    if (trackCache.has(currentWatchId)) return currentWatchId;
    if (!lastCapturedMovieId || Date.now() - watchSince < FALLBACK_DELAY_MS) return null;
    if (warnedFallbackFor !== currentWatchId) {
      warnedFallbackFor = currentWatchId;
      warn('nessun manifest per l\'id ' + currentWatchId + ' dell\'URL: uso l\'ultimo, ' + lastCapturedMovieId);
    }
    return lastCapturedMovieId;
  }

  // Porta lo stato dove deve essere in base a URL, manifest e impostazioni
  function update() {
    if (!settings || !currentWatchId) return;
    const movieId = resolveMovieId();
    if (!movieId) return postStatus(null, 'waiting');
    if (!settings.enabled) return postStatus(movieId, 'disabled');
    if (movieId + '|' + settings.language !== activeKey) return loadSubtitlesFor(movieId);
    if (loadStatus) postStatus(loadStatus.movieId, loadStatus.state, loadStatus.cueCount);
  }

  // Controllo periodico di sicurezza, oltre agli eventi di navigazione
  function tick() {
    try {
      onLocationMaybeChanged();
      update();
    } catch (err) {
      warn('errore nel controllo periodico:', err);
    }
  }

  function installNavigationHooks() {
    for (const name of ['pushState', 'replaceState']) {
      const original = history[name];
      history[name] = function dualSubsHistory() {
        const result = original.apply(this, arguments);
        try {
          onLocationMaybeChanged();
        } catch (err) {
          warn('errore dopo ' + name + ':', err);
        }
        return result;
      };
    }
    window.addEventListener('popstate', tick);
  }

  // -------------------------------------------- messaggi da content.js

  function onWindowMessage(event) {
    const data = event.data;
    if (event.source !== window || !data || data.source !== MSG_SOURCE) return;
    if (data.from !== 'content' || data.type !== 'settings') return;
    settings = data.payload;
    log('impostazioni:', JSON.stringify(settings));
    Overlay.setSettings(settings);
    update();
  }

  // ---------------------------------------------------------------- avvio

  installJsonHooks();
  installResponseJsonHook();
  installNavigationHooks();
  Overlay.init({ log, warn });
  window.addEventListener('message', onWindowMessage);
  setInterval(tick, TICK_MS);
  log('page.js v' + BUILD_VERSION + ' caricato');
  postToContent('page-ready', null);
})();
