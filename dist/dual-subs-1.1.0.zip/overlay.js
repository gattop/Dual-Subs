/*
 * Dual Subs - overlay.js (mondo MAIN)
 *
 * Overlay del secondo sottotitolo: trova il <video> e il contenitore del
 * player (con le regole dell'adattatore della piattaforma), inserisce il <div>
 * e lo aggiorna su timeupdate/seeked. Un MutationObserver lo riaggancia quando
 * il sito ricrea il video o il player.
 * Espone window.DualSubsOverlay.
 */
(function exportOverlay(root) {
  'use strict';

  const OVERLAY_ID = 'dual-subs-overlay';
  const REATTACH_DELAY_MS = 50;

  const state = {
    active: false, // true mentre si è nel player
    video: null,
    overlay: null,
    textEl: null,
    cues: [],
    settings: null,
    lastText: null,
    observer: null,
    reattachPending: false,
    // forniti dall'adattatore della piattaforma
    findVideo: () => null,
    containerSelectors: [],
    log: () => {},
    warn: () => {}
  };

  // --------------------------------------------------------- API pubblica

  // options: { log, warn, findVideo, containerSelectors }
  function init(options) {
    Object.assign(state, options);
    document.addEventListener('fullscreenchange', scheduleAttach);
  }

  // Entrata nel player: osserva il DOM e aggancia l'overlay
  function start() {
    if (state.active) return;
    state.active = true;
    state.observer = state.observer || new MutationObserver(onMutations);
    state.observer.observe(document.documentElement, { childList: true, subtree: true });
    attach();
  }

  // Uscita dal player: rimuove overlay, ascoltatori e osservatore
  function stop() {
    if (!state.active) return;
    state.active = false;
    state.observer.disconnect();
    bindVideo(null);
    if (state.overlay) state.overlay.remove();
    state.cues = [];
    state.lastText = null;
    state.log('overlay rimosso (uscita dal player)');
  }

  function setCues(cues) {
    state.cues = cues;
    render(true);
  }

  function setSettings(settings) {
    state.settings = settings;
    applyStyle();
    render(true);
  }

  // ------------------------------------------------------ elementi del DOM

  function createOverlay() {
    state.overlay = document.createElement('div');
    state.overlay.id = OVERLAY_ID;
    state.overlay.hidden = true;
    state.textEl = document.createElement('span');
    state.textEl.className = 'dual-subs-text';
    state.overlay.appendChild(state.textEl);
    applyStyle();
  }

  // Posizione e dimensione del testo prese dalle impostazioni
  function applyStyle() {
    if (!state.overlay || !state.settings) return;
    state.overlay.className = state.settings.position === 'bottom' ? 'dual-subs-bottom' : 'dual-subs-top';
    state.overlay.style.setProperty('--dual-subs-scale', String(state.settings.scale));
  }

  // Contenitore del player; a schermo intero deve stare dentro l'elemento a
  // schermo intero, altrimenti l'overlay non si vede
  function findContainer(video) {
    let container = null;
    for (const selector of state.containerSelectors) {
      container = video.closest(selector);
      if (container) break;
    }
    container = container || video.parentElement;
    const fullscreen = document.fullscreenElement;
    if (fullscreen && fullscreen.contains(video) && !fullscreen.contains(container)) {
      container = fullscreen;
    }
    return container;
  }

  function describe(el) {
    const uia = el.getAttribute('data-uia');
    const cls = el.classList[0];
    return el.tagName.toLowerCase() + (cls ? '.' + cls : '') + (uia ? '[data-uia="' + uia + '"]' : '');
  }

  // --------------------------------------------------- aggancio e riaggancio

  // Sposta gli ascoltatori sul <video> indicato (null = nessun video)
  function bindVideo(video) {
    if (state.video) {
      state.video.removeEventListener('timeupdate', onTimeUpdate);
      state.video.removeEventListener('seeked', onSeeked);
    }
    state.video = video;
    if (!video) return;
    video.addEventListener('timeupdate', onTimeUpdate);
    video.addEventListener('seeked', onSeeked);
    state.log('agganciato al <video>');
  }

  // Inserisce l'overlay nel contenitore del player, se non c'è già
  function attach() {
    if (!state.active) return;
    const video = state.findVideo();
    if (!video) return;
    if (video !== state.video) bindVideo(video);
    if (!state.overlay) createOverlay();
    const container = findContainer(video);
    if (!container || state.overlay.parentElement === container) return;
    container.appendChild(state.overlay);
    state.log('overlay inserito in', describe(container));
    render(true);
  }

  // Tutto al suo posto: stesso video ancora nella pagina e overlay nel contenitore giusto
  function isAttached() {
    const video = state.video;
    if (!video || !video.isConnected || state.findVideo() !== video) return false;
    return Boolean(state.overlay) && state.overlay.parentElement === findContainer(video);
  }

  function onMutations() {
    if (state.active && !state.reattachPending && !isAttached()) scheduleAttach();
  }

  // Raggruppa le mutazioni ravvicinate in un solo riaggancio
  function scheduleAttach() {
    if (!state.active || state.reattachPending) return;
    state.reattachPending = true;
    setTimeout(() => {
      state.reattachPending = false;
      try {
        attach();
      } catch (err) {
        state.warn('errore nel riaggancio dell\'overlay:', err);
      }
    }, REATTACH_DELAY_MS);
  }

  // ------------------------------------------------------------- disegno

  function activeText() {
    const s = state.settings;
    if (!s || !s.enabled || !state.video || !state.cues.length) return '';
    return root.DualSubsVtt.findActiveCues(state.cues, state.video.currentTime)
      .map((cue) => cue.text)
      .join('\n');
  }

  function render(force) {
    if (!state.overlay) return;
    const text = activeText();
    if (!force && text === state.lastText) return;
    state.lastText = text;
    state.textEl.textContent = text;
    state.overlay.hidden = text === '';
  }

  function onTimeUpdate() {
    try {
      render(false);
    } catch (err) {
      state.warn('errore nell\'aggiornamento dell\'overlay:', err);
    }
  }

  // Dopo un salto: aggiorna subito, senza aspettare il prossimo timeupdate
  function onSeeked() {
    try {
      render(true);
      const video = state.video;
      state.log('salto a', video.currentTime.toFixed(1) + ' s di ' + video.duration.toFixed(1) +
        ' s, battuta:', state.lastText || '(nessuna)');
    } catch (err) {
      state.warn('errore dopo il salto:', err);
    }
  }

  root.DualSubsOverlay = { init, start, stop, setCues, setSettings };
})(typeof globalThis !== 'undefined' ? globalThis : this);
